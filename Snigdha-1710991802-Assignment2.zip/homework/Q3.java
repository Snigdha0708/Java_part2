import java.util.*;
class Q3
{
	public static void main(String[] args) {
		Scanner s=new Scanner(System.in);
		String a=s.nextLine();
		String b=s.nextLine();
		a=a.replaceAll("[\\W]", "");
		a=a.replaceAll(" ","");
		b=b.replaceAll("[\\W]", "");
		b=b.replaceAll(" ","");
		a=a.toLowerCase();
		b=b.toLowerCase();
		char x[]=a.toCharArray();
		char y[]=b.toCharArray();
		Arrays.sort(x);
		Arrays.sort(y);
		String a1="";
		String b1="";
		for(int i=0;i<x.length;i++)
			a1+=x[i];
		for(int i=0;i<y.length;i++)
			b1+=y[i];
		if(a1.equals(b1))
			System.out.println("ANAGRAM!!");
		else
			System.out.println("NOT ANAGRAM!!");
		//System.out.println(a);
		//System.out.println(b);
	}
}