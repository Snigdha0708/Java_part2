import java.util.*;
class Q1
{
	public static void main(String[] args) {
		Scanner s=new Scanner(System.in);
		String a=s.nextLine();
		StringBuffer sb=new StringBuffer(a);
		String n=sb.reverse().toString();
		//System.out.println(n);
		String[] words=n.split(" ");
		String na="";
		for(int i=0;i<words.length;i++)
		{
			StringBuffer sb1=new StringBuffer(words[i]);
            na+=sb1.reverse().toString()+" ";
		}
		System.out.println(na);
		String f="";
		String w[]=na.split(" ");
        f+=w[0]+" ";
        for(int i=1;i<w.length-1;i++)
        {
        	StringBuffer sb2=new StringBuffer(w[i]);
        	f+=sb2.reverse().toString()+" ";
        }
        f+=w[w.length-1];
        System.out.println(f);
	}
}